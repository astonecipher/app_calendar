$(document).ready( function(){

	$(".dates li").click(function () {
	    var val = $(this).attr('id');
	    
	    $.get('api.php?pid=getSchedule&date=' + val, function(data){
	    	$('#schedule').html(data);
	    });
	    $('.modal-title').html("Schedule for: " + val);
	    
	    $('#test_form').modal('show');
	});
	
	
	
	
	
	
	
	
	
	
});









