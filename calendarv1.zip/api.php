<?php

$action = isset($_GET['pid']) ? $_GET['pid'] : '';


switch( $action )
{
    case 'getSchedule':
        echo getSchedule($_GET['date']);
    break;
    default:
        echo "none";
    
}



function getSchedule( $date )
{
    
    $times = [
        '8am', '9am', '10am', '11am', '12pm', '1pm', '2pm', '3pm', '4pm', '5pm', '6pm', '7pm', '8pm', '9pm'
    ];
    
    
    $out = '';
    
    foreach ( $times as $time ){
        $out .= "<div>$time<hr></div>";
    }
    
    return $out;
}